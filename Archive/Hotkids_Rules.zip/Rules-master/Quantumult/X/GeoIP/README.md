范例：

geo_location_checker=http://ifconfig.co/json, https://raw.githubusercontent.com/HotKids/Rules/master/Quantumult/X/GeoIP/IPConfig.js
