# http catcher code open source
> Provide for learning use  
> Share it with friends who need it

使用方法：


![alt ](https://github.com/pm936/http/blob/master/Addmethods.jpg)
