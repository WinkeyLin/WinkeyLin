![Anurag’s github stats](https://github-readme-stats.vercel.app/api?username=nzw9314&show_icons=true&theme=merko)

### 说明 :

* 只是搬运和同步更新大佬脚本.

* 不负责维护脚本.

* 只测试自用脚本，其他大部分脚本未测试可用性.

* 更新通知[频道](https://t.me/nzw9314News)

### 全局配置：

* [QuantumultX.conf](https://raw.githubusercontent.com/nzw9314/QuantumultX/master/QuantumultX.conf)


### 本地配置：

* 建立本地文件夹
目录 iCloud Drive/QuantumultX/Scripts/nzw9314 或者 我的iPhone/QuantumultX/Scripts/nzw9314

* WoringCopy挂载我的[仓库](https://github.com/nzw9314/QuantumultX.git)

* 挂载[视频教程](https://m.youtube.com/watch?t=3s&v=inCQFnDmRLo)

* [Js_local_WorkingCopy.conf](https://raw.githubusercontent.com/nzw9314/QuantumultX/master/Js_local_WorkingCopy.conf) 脚本订阅.

* [Get_Cookie_New.conf](https://raw.githubusercontent.com/nzw9314/QuantumultX/master/Get_Cookie_New.conf) 获取Cookie订阅

* 仅在Cookie获取或失效时启用,不需要时右滑动禁用.

* [Task_Local.conf](https://raw.githubusercontent.com/nzw9314/QuantumultX/master/Task_Local.conf) 定时任务配置,目前无法订阅,请手动根据个人需求复制内容及修改时间.

### 远程配置：
* [视频教程](https://youtu.be/tr5aji82Vks)

* [Js.conf](https://raw.githubusercontent.com/nzw9314/QuantumultX/master/Js.conf) 脚本远程订阅

* [Get_Cookie_Remote.conf](https://raw.githubusercontent.com/nzw9314/QuantumultX/master/Get_Cookie_Remote.conf) 获取Cookie远程订阅,仅在Cookie获取或失效时启用,不需要时右滑动禁用.

* [Task_Remote.conf](https://raw.githubusercontent.com/nzw9314/QuantumultX/master/Task_Remote.conf) 定时任务远程配置,目前无法订阅,请手动根据个人需求复制内容及修改时间


## 免责声明：

* nzw9314发布的Script项目中涉及的任何解锁和解密分析脚本仅用于资源共享和学习研究，不能保证其合法性，准确性，完整性和有效性，请根据情况自行判断.

* 间接使用脚本的任何用户，包括但不限于建立VPS或在某些行为违反国家/地区法律或相关法规的情况下进行传播, nzw9314 对于由此引起的任何隐私泄漏或其他后果概不负责.

* 请勿将Script项目的任何内容用于商业或非法目的，否则后果自负.

* 如果任何单位或个人认为该项目的脚本可能涉嫌侵犯其权利，则应及时通知并提供身份证明，所有权证明，我们将在收到认证文件后删除相关脚本.

* nzw9314对任何脚本问题概不负责，包括但不限于由任何脚本错误导致的任何损失或损害.

* 您必须在下载后的24小时内从计算机或手机中完全删除以上内容.

* 任何以任何方式查看此项目的人或直接或间接使用该Script项目的任何脚本的使用者都应仔细阅读此声明。nzw9314保留随时更改或补充此免责声明的权利。一旦使用并复制了任何相关脚本或Script项目的规则，则视为您已接受此免责声明.

### 特别感谢：
* [Qure](https://github.com/Koolson/Qure)

* [Orz](https://github.com/Orz-3/mini)

* [@NobyDa](https://github.com/NobyDa)

* [@lhie1](https://github.com/lhie1)

* [@ConnersHua](https://github.com/DivineEngine/Profiles/tree/master)

* [@chavyleung](https://github.com/chavyleung)

* [@yichahucha](https://github.com/yichahucha)

* [@langkhach270389](https://github.com/langkhach270389)

* [@Choler](https://github.com/Choler)

* [@onewayticket255](https://github.com/onewayticket255)

* [@NavePnow](https://github.com/NavePnow)

* [@Meeta](https://github.com/MeetaGit)

* [@Neurogram-R](https://github.com/Neurogram-R)

* [@sazs34](https://github.com/sazs34)

* [@uniqueque](https://github.com/uniqueque)

* [@eHpo](https://github.com/eHpo1/Rules)

* [@Sunert](https://github.com/Sunert/Scripts)

* [@songyangzz](https://github.com/songyangzz/QuantumultX.git)

* [@zZPiglet](https://github.com/zZPiglet/Task.git)

* [@Peng-YM](https://github.com/Peng-YM/QuanX)

* [@evilbutcher](https://github.com/evilbutcher/Quantumult_X/tree/master)

* [@lxk0301](https://gitee.com/lxk0301/scripts)

* [@toulanboy](https://github.com/toulanboy/scripts)

* [@lowking](https://github.com/lowking/Scripts)


## License

[GPLv3](LICENSE)