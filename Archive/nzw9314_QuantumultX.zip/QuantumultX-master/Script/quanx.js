var body = $response.body;
body = '\/*\n@supported B422643B7EE6\n*\/\n' + body;

$done(body);