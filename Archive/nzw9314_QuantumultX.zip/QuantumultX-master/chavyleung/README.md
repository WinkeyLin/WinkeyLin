# Chavy Scripts
![](https://img.shields.io/badge/license-MIT-blueviolet.svg)
![GitHub release (latest by date)](https://img.shields.io/github/v/release/chavyleung/scripts?color=%23c694ff)
![](https://badgen.net/github/stars/chavyleung/scripts)
![](https://tokei.rs/b1/github/chavyleung/scripts?category=code)
![GitHub contributors](https://img.shields.io/github/contributors/chavyleung/scripts)
# BoxJs
A SPA Appliction be used for scripts utils

![Demo](https://github.com/chavyleung/scripts/blob/master/BoxJS.gif)

[Scripts Vote](https://t.me/chavyscripts)

# LICENSE
Copyright © 2019-present chavyleung. This project is [GPL](https://github.com/chavyleung/scripts/blob/master/LICENSE) licensed.