# 苏宁易购

> 代码已同时兼容 Surge & QuanX, 使用同一份签到脚本即可

> 有一定动手及排查问题能力的同学先上车

> 2020.3.15 增加天天低价, 注意更新`mitm`和`rewrite`并进入天天低价获取两次 Cookie

> 2020.3.16 修复部分机型的`天天红包`就算 Cookie 获取成功也会签到失败问题

> 2020.5.7 修复部分场景下报`d.obj.couponRuleName`问题

## 配置 (Surge)

```properties
[MITM]
hostname = passport.suning.com, luckman.suning.com, sign.suning.com, gameapi.suning.com

[Script]
# 注意有4条获取 Cookie 脚本
http-request ^https:\/\/passport.suning.com\/ids\/login$ script-path=https://raw.githubusercontent.com/chavyleung/scripts/master/suning/suning.cookie.js, requires-body=true
http-request ^https:\/\/luckman.suning.com\/luck-web\/sign\/api\/clock_sign.do script-path=https://raw.githubusercontent.com/chavyleung/scripts/master/suning/suning.cookie.js
http-request ^https:\/\/sign.suning.com\/sign-web\/m\/promotion\/sign\/doSign.do script-path=https://raw.githubusercontent.com/chavyleung/scripts/master/suning/suning.cookie.js
http-request ^https:\/\/gameapi.suning.com\/sngame-web\/(api\/signin\/private\/customerSignOperation.do|gateway\/api\/queryPrize.do) script-path=https://raw.githubusercontent.com/chavyleung/scripts/master/suning/suning.cookie.js
cron "10 0 0 * * *" script-path=https://raw.githubusercontent.com/chavyleung/scripts/master/suning/suning.js
```

## 配置 (QuanX)

```properties
[MITM]
hostname = passport.suning.com, luckman.suning.com, sign.suning.com, gameapi.suning.com

[rewrite_local]
# 注意有4条获取 Cookie 脚本
^https:\/\/passport.suning.com\/ids\/login$ url script-request-body suning.cookie.js
^https:\/\/luckman.suning.com\/luck-web\/sign\/api\/clock_sign.do url script-request-header suning.cookie.js
^https:\/\/sign.suning.com\/sign-web\/m\/promotion\/sign\/doSign.do url script-request-header suning.cookie.js
^https:\/\/gameapi.suning.com\/sngame-web\/(api\/signin\/private\/customerSignOperation.do|gateway\/api\/queryPrize.do) url script-request-header suning.cookie.js

[task_local]
1 0 * * * suning.js
```

## 说明

1. 先把`passport.suning.com, luckman.suning.com, sign.suning.com, gameapi.suning.com`加到`[MITM]`
2. 再配置重写规则:
   - Surge: 把两条远程脚本放到`[Script]`
   - QuanX: 把`suning.cookie.js`和`suning.js`传到`On My iPhone - Quantumult X - Scripts` (传到 iCloud 相同目录也可, 注意要打开 quanx 的 iCloud 开关)
3. 获取 Cookie:
   - 【必要】打开 APP, 系统提示: `获取Cookie: 成功 (登录链接)`
   - 【可选】进入 `主页` > `签到有礼`, 系统提示: `获取Cookie: 成功 (每日签到)`
   - 【可选】进入 `主页` > `领取红包`, 系统提示: `获取Cookie: 成功 (每日红包)` (如果找不到领取红包，尝试卸载苏宁重新安装) 兼容之前 @barrymchen 写的 snyg.js 如果之前有用这个脚本获取过 Cookie 那不用重新取
   - 【可选】进入 `主页` > `天天低价` > `点右上角宝箱`, 系统提示: `获取Cookie: 成功 (天天低价)`、`获取Cookie: 成功 (查询天天低价)`
4. 把获取 Cookie 的脚本注释或删掉

> 第 1 条脚本是用来获取 cookie 的, 用浏览器访问一次获取 cookie 成功后就可以删掉或注释掉了, 但请确保在`登录成功`后再获取 cookie.

> 第 2 条脚本是签到脚本, 每天`00:00:10`执行一次.

## 常见问题

1. 无法写入 Cookie

   - 检查 Surge 系统通知权限放开了没
   - 如果你用的是 Safari, 请尝试在浏览地址栏`手动输入网址`(不要用复制粘贴)

2. 写入 Cookie 成功, 但签到不成功

   - 看看是不是在登录前就写入 Cookie 了
   - 如果是，请确保在登录成功后，再尝试写入 Cookie

3. 为什么有时成功有时失败

   - 很正常，网络问题，哪怕你是手工签到也可能失败（凌晨签到容易拥堵就容易失败）
   - 暂时不考虑代码级的重试机制，但咱有配置级的（暴力美学）：

   - `Surge`配置:

     ```properties
     # 没有什么是一顿饭解决不了的:
     cron "10 0 0 * * *" script-path=xxx.js # 每天00:00:10执行一次
     # 如果有，那就两顿:
     cron "20 0 0 * * *" script-path=xxx.js # 每天00:00:20执行一次
     # 实在不行，三顿也能接受:
     cron "30 0 0 * * *" script-path=xxx.js # 每天00:00:30执行一次

     # 再粗暴点，直接:
     cron "* */60 * * * *" script-path=xxx.js # 每60分执行一次
     ```

   - `QuanX`配置:

     ```properties
     [task_local]
     1 0 * * * xxx.js # 每天00:01执行一次
     2 0 * * * xxx.js # 每天00:02执行一次
     3 0 * * * xxx.js # 每天00:03执行一次

     */60 * * * * xxx.js # 每60分执行一次
     ```

## 感谢

[@NobyDa](https://github.com/NobyDa)

[@lhie1](https://github.com/lhie1)

[@ConnersHua](https://github.com/ConnersHua)

@makexp
