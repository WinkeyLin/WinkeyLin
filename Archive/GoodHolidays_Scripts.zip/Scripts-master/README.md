
<div align="center"> 
<h1 align="center">本仓库不再维护</h1>
<img src="https://img.shields.io/github/issues/Sunert/Scripts?color=green">
<img src="https://img.shields.io/github/stars/Sunert/Scripts?color=yellow">
<img src="https://img.shields.io/github/forks/Sunert/Scripts?color=orange">
<img src="https://img.shields.io/github/license/Sunert/Scripts?color=ff69b4">
<img src="https://img.shields.io/github/languages/code-size/Sunert/Scripts?color=blueviolet">
</div>

<br>

[跳转到任务配置](https://github.com/Sunert/Scripts/tree/master/TaskConf) --- [跳转到脚本列表](https://github.com/Sunert/Scripts/tree/master/Task)

***

## 免责声明: 

* 本仓库发布的Script项目中涉及的任何解锁和解密分析脚本，仅用于测试和学习研究，禁止用于商业用途，不能保证其合法性，准确性，完整性和有效性，请根据情况自行判断.

* Sunert对任何脚本问题概不负责，包括但不限于由任何脚本错误导致的任何损失或损害.

* 间接使用脚本的任何用户，包括但不限于建立VPS或在某些行为违反国家/地区法律或相关法规的情况下进行传播, Sunert 对于由此引起的任何隐私泄漏或其他后果概不负责.

* 请勿将Script项目的任何内容用于商业或非法目的，否则后果自负.

* 如果任何单位或个人认为该项目的脚本可能涉嫌侵犯其权利，则应及时通知并提供身份证明，所有权证明，我们将在收到认证文件后删除相关脚本.

* 任何以任何方式查看此项目的人或直接或间接使用该Script项目的任何脚本的使用者都应仔细阅读此声明。Sunert保留随时更改或补充此免责声明的权利。一旦使用并复制了任何相关脚本或Script项目的规则，则视为您已接受此免责声明.

- 您必须在下载后的24小时内从计算机或手机中完全删除以上内容.   </br>
<div align=center >   您使用或者复制了本仓库且本人制作的任何脚本，则视为 <span style="font-size:25px;color:#FF0000">已接受</span> 此免责声明，请仔细阅读
<div>

***

#### 开发者不易,请赏杯茶水费
<div align=center><img width="200" height="200" src="https://gitee.com/Sunert/Profiles/raw/master/QuantumultX/Rules/Images/Complimentcode.jpeg"/></div>
<br>

---

### 特别感谢：

  * [@chavyleung](https://github.com/chavyleung)

  * [@NobyDa](https://github.com/NobyDa)

  * [@lxk0301](https://github.com/lxk0301)

  * [@id77_Github](https://github.com/id77)
